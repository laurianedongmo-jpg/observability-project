'use strict';

const { SpanStatusCode } = require('@opentelemetry/api');

/**
 * Exécute `fn` dans un span enfant nommé (span actif pendant l'exécution),
 * en enregistrant l'exception et le statut d'erreur le cas échéant.
 */
async function withSpan(tracer, name, attributes, fn) {
  return tracer.startActiveSpan(name, { attributes }, async (span) => {
    try {
      return await fn(span);
    } catch (err) {
      span.recordException(err);
      span.setStatus({ code: SpanStatusCode.ERROR, message: err.code || err.name });
      throw err;
    } finally {
      span.end();
    }
  });
}

module.exports = { withSpan };
