'use strict';

/**
 * Données FICTIVES. Aucune donnée personnelle réelle.
 * Les adresses e-mail sont masquées avant d'être renvoyées par l'API
 * (principe de minimisation des données).
 */
const USERS = [
  { id: 1, firstName: 'Awa', lastName: 'Ndiaye', email: 'awa.ndiaye@example.com', role: 'admin' },
  { id: 2, firstName: 'Jean', lastName: 'Mballa', email: 'jean.mballa@example.com', role: 'user' },
  { id: 3, firstName: 'Fatou', lastName: 'Diallo', email: 'fatou.diallo@example.com', role: 'user' },
  { id: 4, firstName: 'Paul', lastName: 'Etoundi', email: 'paul.etoundi@example.com', role: 'manager' },
  { id: 5, firstName: 'Mariam', lastName: 'Kone', email: 'mariam.kone@example.com', role: 'user' },
];

const PRODUCTS = [
  { sku: 'LAP-001', name: 'Ordinateur portable 14"', category: 'informatique', price: 649.0, currency: 'EUR' },
  { sku: 'MON-002', name: 'Écran 27" QHD', category: 'informatique', price: 279.9, currency: 'EUR' },
  { sku: 'KEY-003', name: 'Clavier mécanique', category: 'accessoires', price: 89.5, currency: 'EUR' },
  { sku: 'MOU-004', name: 'Souris sans fil', category: 'accessoires', price: 34.99, currency: 'EUR' },
  { sku: 'HDS-005', name: 'Casque audio', category: 'audio', price: 129.0, currency: 'EUR' },
];

const STOCK = {
  'LAP-001': 12,
  'MON-002': 0,
  'KEY-003': 54,
  'MOU-004': 230,
  'HDS-005': 7,
};

function maskEmail(email) {
  const [local, domain] = String(email).split('@');
  if (!domain) return '***';
  return `${local.charAt(0)}***@${domain}`;
}

function publicUser(user) {
  return {
    id: user.id,
    firstName: user.firstName,
    lastName: user.lastName.charAt(0) + '.',
    email: maskEmail(user.email),
    role: user.role,
  };
}

module.exports = { USERS, PRODUCTS, STOCK, maskEmail, publicUser };
