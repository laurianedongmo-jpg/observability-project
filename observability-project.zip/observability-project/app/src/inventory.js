'use strict';

const express = require('express');
const { setTimeout: sleep } = require('node:timers/promises');
const { trace } = require('@opentelemetry/api');
const { version } = require('../package.json');
const { createHttpMetrics, httpObservabilityMiddleware } = require('./telemetry');
const { AppError, errorHandler, notFoundHandler } = require('./errors');
const { withSpan } = require('./tracing');
const { STOCK } = require('./data');

/**
 * Service « inventory » : second microservice appelé par l'API.
 * Il permet d'obtenir de vraies traces distribuées (2 services, 1 trace).
 */
function createInventoryApp({ config, logger }) {
  const app = express();
  const tracer = trace.getTracer(config.serviceName, version);
  const httpMetrics = createHttpMetrics(config.serviceName);

  app.disable('x-powered-by');
  app.use(httpObservabilityMiddleware({ httpMetrics, logger, slowThresholdMs: config.slowThresholdMs }));

  app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: config.serviceName, uptimeSeconds: Math.round(process.uptime()) });
  });

  app.get('/inventory/stock', async (req, res) => {
    if (config.inventoryFailureRate > 0 && Math.random() < config.inventoryFailureRate) {
      throw new AppError('Panne simulée du stockage inventory', { status: 503, code: 'SIMULATED_OUTAGE' });
    }
    const stock = await withSpan(
      tracer,
      'cache.lookup stock',
      { 'db.system.name': 'in-memory', 'db.operation.name': 'GET', 'db.collection.name': 'stock' },
      async () => {
        await sleep(10 + Math.floor(Math.random() * 40));
        return STOCK;
      },
    );
    logger.info({ event: 'stock_served', items: Object.keys(stock).length }, 'Stock renvoyé');
    res.json({ stock });
  });

  app.use(notFoundHandler);
  app.use(errorHandler(logger));
  return app;
}

module.exports = { createInventoryApp };
