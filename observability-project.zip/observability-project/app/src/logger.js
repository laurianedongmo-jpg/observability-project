'use strict';

const pino = require('pino');

/**
 * Logger JSON structuré.
 *
 * - Écrit sur stdout (visible avec `docker compose logs`).
 * - L'instrumentation pino d'OpenTelemetry ajoute automatiquement
 *   trace_id / span_id / trace_flags et transmet chaque log au SDK Logs
 *   OpenTelemetry, qui l'exporte en OTLP vers le Collector puis Loki.
 * - Les champs potentiellement sensibles sont masqués (redact).
 */
function createLogger({ serviceName, level }) {
  return pino({
    level,
    base: { service: serviceName },
    timestamp: pino.stdTimeFunctions.isoTime,
    redact: {
      paths: [
        'req.headers.authorization',
        'req.headers.cookie',
        'headers.authorization',
        'headers.cookie',
        '*.password',
        '*.email',
        '*.token',
      ],
      censor: '[REDACTED]',
    },
  });
}

module.exports = { createLogger };
