'use strict';

/**
 * Point d'entrée. Lancer avec :
 *   node --require ./src/instrumentation.js src/server.js
 * La variable SERVICE_ROLE choisit le service : "api" (défaut) ou "inventory".
 */

const { loadConfig } = require('./config');
const { createLogger } = require('./logger');

const config = loadConfig();
const logger = createLogger({ serviceName: config.serviceName, level: config.logLevel });

// Si l'instrumentation a été préchargée (--require), on récupère sa fonction
// d'arrêt pour vider les buffers de télémétrie à l'arrêt du conteneur.
let shutdownTelemetry = async () => {};
const instrumentationPath = require.resolve('./instrumentation');
if (require.cache[instrumentationPath]) {
  ({ shutdownTelemetry } = require('./instrumentation'));
} else {
  logger.warn('OpenTelemetry non préchargé : lancez Node avec --require ./src/instrumentation.js');
}

const app = config.role === 'api'
  ? require('./app').createApiApp({ config, logger })
  : require('./inventory').createInventoryApp({ config, logger });

const server = app.listen(config.port, '0.0.0.0', () => {
  logger.info({ event: 'startup', role: config.role, port: config.port }, `Service ${config.serviceName} démarré sur le port ${config.port}`);
});

// Évite les connexions zombies derrière un proxy.
server.keepAliveTimeout = 65_000;
server.headersTimeout = 66_000;

let stopping = false;
function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  logger.info({ event: 'shutdown', signal }, `Signal ${signal} reçu, arrêt en cours`);
  const forceExit = setTimeout(() => process.exit(1), 10_000);
  forceExit.unref();
  server.close(async () => {
    await shutdownTelemetry();
    process.exit(0);
  });
  server.closeIdleConnections();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error({ event: 'unhandled_rejection', err: reason }, 'Promesse rejetée non gérée');
});
