'use strict';

const express = require('express');
const { setTimeout: sleep } = require('node:timers/promises');
const { trace } = require('@opentelemetry/api');
const { version } = require('../package.json');
const { createHttpMetrics, httpObservabilityMiddleware } = require('./telemetry');
const { withSpan } = require('./tracing');
const { AppError, errorHandler, notFoundHandler } = require('./errors');
const { USERS, PRODUCTS, publicUser } = require('./data');

const ALLOWED_ERROR_CODES = new Set([500, 502, 503, 504]);

function randomInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

/**
 * Construit l'application Express du service « api ».
 */
function createApiApp({ config, logger }) {
  const app = express();
  const tracer = trace.getTracer(config.serviceName, version);
  const httpMetrics = createHttpMetrics(config.serviceName);

  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Cache-Control', 'no-store');
    next();
  });
  app.use(httpObservabilityMiddleware({ httpMetrics, logger, slowThresholdMs: config.slowThresholdMs }));

  app.get('/', (req, res) => {
    res.json({
      name: 'Demo API - plateforme d\'observabilité',
      version,
      description: 'API REST instrumentée avec OpenTelemetry (traces, métriques, logs).',
      endpoints: {
        'GET /': 'Présentation de l\'API',
        'GET /health': 'État de santé du service',
        'GET /api/users': 'Liste d\'utilisateurs fictifs',
        'GET /api/products': 'Liste de produits fictifs (+ stock via le service inventory)',
        'GET /api/slow?delay=<ms>': `Requête lente simulée (défaut ${config.slowMinDelayMs}-${config.slowMaxDelayMs} ms, max ${config.maxSlowDelayMs} ms)`,
        'GET /api/error?code=<500|502|503|504>': 'Erreur HTTP simulée (défaut 500)',
      },
      telemetry: 'Les métriques sont poussées en OTLP vers OpenTelemetry Collector (pas d\'endpoint /metrics local).',
    });
  });

  app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: config.serviceName, uptimeSeconds: Math.round(process.uptime()) });
  });

  app.get('/api/users', async (req, res) => {
    // Simule une requête en base de données sous forme de span enfant.
    const users = await withSpan(
      tracer,
      'db.query users',
      { 'db.system.name': 'in-memory', 'db.operation.name': 'SELECT', 'db.collection.name': 'users' },
      async (span) => {
        await sleep(randomInt(5, 30));
        span.setAttribute('db.response.returned_rows', USERS.length);
        return USERS.map(publicUser);
      },
    );
    // On n'enregistre que des volumes, jamais de données personnelles, dans la télémétrie.
    trace.getActiveSpan()?.setAttribute('app.users.count', users.length);
    logger.info({ event: 'users_listed', count: users.length }, 'Liste des utilisateurs renvoyée');
    res.json({ count: users.length, data: users });
  });

  app.get('/api/products', async (req, res) => {
    const products = await withSpan(
      tracer,
      'db.query products',
      { 'db.system.name': 'in-memory', 'db.operation.name': 'SELECT', 'db.collection.name': 'products' },
      async () => {
        await sleep(randomInt(5, 20));
        return PRODUCTS;
      },
    );

    // Appel HTTP vers le service inventory : fetch() est instrumenté (undici),
    // l'en-tête W3C `traceparent` est propagé => une seule trace distribuée.
    let stock;
    try {
      const response = await fetch(`${config.inventoryUrl}/inventory/stock`, {
        signal: AbortSignal.timeout(config.upstreamTimeoutMs),
        headers: { accept: 'application/json' },
      });
      if (!response.ok) {
        throw new AppError(`inventory a répondu ${response.status}`, { status: 502, code: 'UPSTREAM_ERROR' });
      }
      stock = (await response.json()).stock;
    } catch (err) {
      if (err instanceof AppError) throw err;
      const timeout = err.name === 'TimeoutError';
      throw new AppError(`Appel inventory impossible: ${err.message}`, {
        status: timeout ? 504 : 502,
        code: timeout ? 'UPSTREAM_TIMEOUT' : 'UPSTREAM_UNAVAILABLE',
      });
    }

    const data = products.map((p) => ({ ...p, stock: stock[p.sku] ?? null, available: (stock[p.sku] ?? 0) > 0 }));
    trace.getActiveSpan()?.setAttribute('app.products.count', data.length);
    res.json({ count: data.length, data });
  });

  app.get('/api/slow', async (req, res) => {
    let delay;
    if (req.query.delay !== undefined) {
      delay = Number.parseInt(String(req.query.delay), 10);
      if (Number.isNaN(delay) || delay < 0 || delay > config.maxSlowDelayMs) {
        throw new AppError(`Paramètre delay invalide: ${req.query.delay}`, {
          status: 400,
          code: 'INVALID_PARAMETER',
          publicMessage: `Le paramètre delay doit être un entier entre 0 et ${config.maxSlowDelayMs}.`,
        });
      }
    } else {
      delay = randomInt(config.slowMinDelayMs, config.slowMaxDelayMs);
    }

    await withSpan(tracer, 'simulate.slow_operation', { 'app.simulated_delay_ms': delay }, async (span) => {
      span.addEvent('début du traitement lent');
      await sleep(delay);
      span.addEvent('fin du traitement lent');
    });
    logger.info({ event: 'slow_simulated', delay_ms: delay }, `Traitement lent simulé (${delay} ms)`);
    res.json({ message: 'Réponse lente simulée', delayMs: delay });
  });

  app.get('/api/error', async (req, res) => {
    const requested = req.query.code !== undefined ? Number.parseInt(String(req.query.code), 10) : 500;
    const status = ALLOWED_ERROR_CODES.has(requested) ? requested : 500;
    await withSpan(tracer, 'simulate.failing_operation', { 'app.simulated_status': status }, async () => {
      await sleep(randomInt(5, 25));
      // Le message interne (avec un faux détail technique) n'est JAMAIS renvoyé au client.
      throw new AppError('Échec simulé: connexion à la ressource interne db-primary:5432 refusée', {
        status,
        code: 'SIMULATED_FAILURE',
      });
    });
  });

  app.use(notFoundHandler);
  app.use(errorHandler(logger));
  return app;
}

module.exports = { createApiApp };
