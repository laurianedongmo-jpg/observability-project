'use strict';

const { trace, SpanStatusCode } = require('@opentelemetry/api');

/**
 * Erreur applicative : `publicMessage` est le seul texte renvoyé au client.
 * Le message interne et la pile d'appel restent côté serveur (logs, traces).
 */
class AppError extends Error {
  constructor(message, { status = 500, code = 'INTERNAL_ERROR', publicMessage } = {}) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.publicMessage = publicMessage || defaultPublicMessage(status);
  }
}

function defaultPublicMessage(status) {
  if (status === 400) return 'Requête invalide.';
  if (status === 404) return 'Ressource introuvable.';
  if (status === 502) return 'Un service dépendant est indisponible.';
  if (status === 503) return 'Service temporairement indisponible.';
  if (status === 504) return 'Le délai de réponse a été dépassé.';
  return 'Une erreur interne est survenue.';
}

function currentTraceId() {
  const span = trace.getActiveSpan();
  const ctx = span && span.spanContext();
  return ctx && trace.isSpanContextValid(ctx) ? ctx.traceId : undefined;
}

function notFoundHandler(req, res) {
  res.status(404).json({
    error: { code: 'NOT_FOUND', message: defaultPublicMessage(404) },
    traceId: currentTraceId(),
  });
}

/**
 * Gestionnaire d'erreurs central (Express : 4 arguments).
 * - Enregistre l'exception dans la trace active (visible dans Jaeger).
 * - Journalise le détail côté serveur.
 * - Renvoie au client un message générique, sans pile ni détail interne.
 */
function errorHandler(logger) {
  // eslint-disable-next-line no-unused-vars
  return function handleError(err, req, res, next) {
    const isAppError = err instanceof AppError;
    // Erreurs de parsing ou levées par Express (ex: 400) ont parfois un status.
    const rawStatus = isAppError ? err.status : (err.status || err.statusCode || 500);
    const status = rawStatus >= 400 && rawStatus < 600 ? rawStatus : 500;
    const code = isAppError ? err.code : (status >= 500 ? 'INTERNAL_ERROR' : 'BAD_REQUEST');

    const span = trace.getActiveSpan();
    if (span) {
      span.recordException(err);
      if (status >= 500) {
        span.setStatus({ code: SpanStatusCode.ERROR, message: code });
      }
      span.setAttribute('app.error.code', code);
    }

    const logPayload = { event: 'request_error', code, status, err };
    if (status >= 500) logger.error(logPayload, `Erreur ${status} (${code}): ${err.message}`);
    else logger.warn(logPayload, `Erreur ${status} (${code}): ${err.message}`);

    if (res.headersSent) {
      return;
    }
    res.status(status).json({
      error: { code, message: isAppError ? err.publicMessage : defaultPublicMessage(status) },
      traceId: currentTraceId(),
    });
  };
}

module.exports = { AppError, errorHandler, notFoundHandler, currentTraceId };
