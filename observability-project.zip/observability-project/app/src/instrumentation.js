'use strict';

/**
 * Initialisation d'OpenTelemetry.
 *
 * Ce fichier DOIT être chargé avant tout autre module (option Node
 * `--require ./src/instrumentation.js`) afin que les bibliothèques http,
 * express, undici (fetch) et pino soient instrumentées au moment de leur
 * premier chargement.
 *
 * La configuration des exportateurs est volontairement pilotée par les
 * variables d'environnement standard OpenTelemetry (OTEL_*), définies dans
 * compose.yaml :
 *   - OTEL_SERVICE_NAME, OTEL_RESOURCE_ATTRIBUTES  -> identité du service
 *   - OTEL_EXPORTER_OTLP_ENDPOINT / _PROTOCOL       -> destination (le Collector)
 *   - OTEL_TRACES_EXPORTER / METRICS / LOGS         -> "otlp" ou "none"
 *   - OTEL_METRIC_EXPORT_INTERVAL                    -> fréquence d'envoi des métriques
 *   - OTEL_TRACES_SAMPLER / _ARG                     -> échantillonnage
 */

const { NodeSDK } = require('@opentelemetry/sdk-node');
const { diag, DiagConsoleLogger, DiagLogLevel } = require('@opentelemetry/api');
const { HttpInstrumentation } = require('@opentelemetry/instrumentation-http');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');
const { UndiciInstrumentation } = require('@opentelemetry/instrumentation-undici');
const { PinoInstrumentation } = require('@opentelemetry/instrumentation-pino');
const { RuntimeNodeInstrumentation } = require('@opentelemetry/instrumentation-runtime-node');

// Journalisation interne du SDK (erreurs d'export, etc.). "warn" par défaut.
const diagLevel = (process.env.OTEL_LOG_LEVEL || 'warn').toUpperCase();
diag.setLogger(new DiagConsoleLogger(), DiagLogLevel[diagLevel] ?? DiagLogLevel.WARN);

// Requêtes techniques exclues des traces (sondes de santé), pour ne pas
// noyer Jaeger sous des traces sans intérêt.
const IGNORED_PATHS = new Set(['/health', '/favicon.ico']);

function pathOf(url) {
  if (!url) return '';
  const q = url.indexOf('?');
  return q === -1 ? url : url.slice(0, q);
}

const sdk = new NodeSDK({
  instrumentations: [
    new HttpInstrumentation({
      ignoreIncomingRequestHook: (req) => IGNORED_PATHS.has(pathOf(req.url)),
    }),
    // On ne garde que les spans des handlers de routes : les spans de
    // middlewares (en-têtes, mesure...) ajoutent du bruit sans valeur.
    new ExpressInstrumentation({ ignoreLayersType: ['middleware'] }),
    // Instrumente fetch() (undici) : propage le contexte W3C traceparent
    // vers le service inventory -> trace distribuée.
    new UndiciInstrumentation(),
    // Injecte trace_id/span_id dans chaque log pino ET transmet les logs au
    // SDK Logs OpenTelemetry (export OTLP vers le Collector).
    new PinoInstrumentation(),
    // Métriques du runtime Node.js (event loop, heap, GC).
    new RuntimeNodeInstrumentation({ monitoringPrecision: 5000 }),
  ],
});

sdk.start();

let shuttingDown = null;
/**
 * Vide les buffers de télémétrie (spans, métriques, logs) avant l'arrêt.
 */
function shutdownTelemetry() {
  if (!shuttingDown) {
    shuttingDown = sdk.shutdown().catch((err) => {
      // eslint-disable-next-line no-console
      console.error('Erreur lors de l\'arrêt du SDK OpenTelemetry', err);
    });
  }
  return shuttingDown;
}

module.exports = { sdk, shutdownTelemetry };
