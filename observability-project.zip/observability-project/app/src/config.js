'use strict';

function intFromEnv(name, defaultValue, { min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return defaultValue;
  const value = Number.parseInt(raw, 10);
  if (Number.isNaN(value) || value < min || value > max) {
    throw new Error(`Variable d'environnement invalide ${name}=${raw} (attendu: entier entre ${min} et ${max})`);
  }
  return value;
}

function floatFromEnv(name, defaultValue, { min = 0, max = 1 } = {}) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return defaultValue;
  const value = Number.parseFloat(raw);
  if (Number.isNaN(value) || value < min || value > max) {
    throw new Error(`Variable d'environnement invalide ${name}=${raw} (attendu: nombre entre ${min} et ${max})`);
  }
  return value;
}

function loadConfig() {
  const role = process.env.SERVICE_ROLE || 'api';
  if (!['api', 'inventory'].includes(role)) {
    throw new Error(`SERVICE_ROLE invalide: ${role} (valeurs acceptées: api, inventory)`);
  }
  return {
    role,
    port: intFromEnv('PORT', role === 'api' ? 8080 : 8081, { min: 1, max: 65535 }),
    serviceName: process.env.OTEL_SERVICE_NAME || (role === 'api' ? 'demo-api' : 'inventory-service'),
    logLevel: process.env.LOG_LEVEL || 'info',
    inventoryUrl: process.env.INVENTORY_URL || 'http://localhost:8081',
    upstreamTimeoutMs: intFromEnv('UPSTREAM_TIMEOUT_MS', 2000, { min: 100, max: 30000 }),
    // Une requête est considérée « lente » au-delà de ce seuil.
    slowThresholdMs: intFromEnv('SLOW_REQUEST_THRESHOLD_MS', 1000, { min: 1, max: 60000 }),
    // Bornes de la latence simulée par /api/slow.
    slowMinDelayMs: intFromEnv('SLOW_MIN_DELAY_MS', 1000, { min: 0, max: 30000 }),
    slowMaxDelayMs: intFromEnv('SLOW_MAX_DELAY_MS', 3000, { min: 0, max: 30000 }),
    maxSlowDelayMs: intFromEnv('SLOW_MAX_ALLOWED_DELAY_MS', 5000, { min: 0, max: 30000 }),
    // Taux de panne simulée du service inventory (0 = jamais, 1 = toujours).
    inventoryFailureRate: floatFromEnv('INVENTORY_FAILURE_RATE', 0),
  };
}

module.exports = { loadConfig };
