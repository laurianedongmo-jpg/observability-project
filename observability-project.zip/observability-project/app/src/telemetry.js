'use strict';

const { metrics } = require('@opentelemetry/api');
const { version } = require('../package.json');

// Bornes des histogrammes de durée, en secondes (5 ms -> 10 s).
const DURATION_BUCKETS_SECONDS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.5, 2.5, 5, 7.5, 10];

/**
 * Métriques HTTP applicatives (en plus de la métrique standard
 * `http.server.request.duration` produite automatiquement par
 * l'instrumentation http).
 *
 * Noms OpenTelemetry -> noms Prometheus (conversion faite par l'exporter
 * `prometheus` du Collector) :
 *   app.http.requests          -> app_http_requests_total
 *   app.http.request.duration  -> app_http_request_duration_seconds_{bucket,sum,count}
 *   app.http.slow_requests     -> app_http_slow_requests_total
 *   app.http.active_requests   -> app_http_active_requests
 */
function createHttpMetrics(serviceName) {
  const meter = metrics.getMeter(serviceName, version);
  return {
    requests: meter.createCounter('app.http.requests', {
      description: 'Nombre total de requêtes HTTP traitées',
      unit: '{request}',
    }),
    duration: meter.createHistogram('app.http.request.duration', {
      description: 'Durée de traitement des requêtes HTTP',
      unit: 's',
      advice: { explicitBucketBoundaries: DURATION_BUCKETS_SECONDS },
    }),
    slowRequests: meter.createCounter('app.http.slow_requests', {
      description: 'Nombre de requêtes HTTP dépassant le seuil de lenteur',
      unit: '{request}',
    }),
    activeRequests: meter.createUpDownCounter('app.http.active_requests', {
      description: 'Nombre de requêtes HTTP en cours de traitement',
      unit: '{request}',
    }),
  };
}

/**
 * Détermine la route « modèle » (ex: /api/users) et non l'URL brute,
 * pour éviter l'explosion de cardinalité des labels Prometheus et ne pas
 * enregistrer de paramètres (potentiellement personnels) dans les métriques.
 */
function routeOf(req, res) {
  if (req.route && req.route.path) {
    return `${req.baseUrl || ''}${req.route.path}`;
  }
  return res.statusCode === 404 ? 'unmatched' : 'unknown';
}

/**
 * Middleware Express : mesure chaque requête et journalise un log d'accès.
 */
function httpObservabilityMiddleware({ httpMetrics, logger, slowThresholdMs }) {
  return function observe(req, res, next) {
    const start = process.hrtime.bigint();
    const method = req.method;
    httpMetrics.activeRequests.add(1, { 'http.request.method': method });

    let done = false;
    const finish = (aborted) => {
      if (done) return;
      done = true;
      const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
      const route = routeOf(req, res);
      const status = aborted ? 499 : res.statusCode;
      const attributes = {
        'http.request.method': method,
        'http.route': route,
        'http.response.status_code': status,
        'http.response.status_class': `${Math.floor(status / 100)}xx`,
      };

      httpMetrics.activeRequests.add(-1, { 'http.request.method': method });
      httpMetrics.requests.add(1, attributes);
      httpMetrics.duration.record(durationMs / 1000, attributes);
      const slow = durationMs >= slowThresholdMs;
      if (slow) {
        httpMetrics.slowRequests.add(1, { 'http.request.method': method, 'http.route': route });
      }

      // Log d'accès : pas d'adresse IP ni de query string (données personnelles potentielles).
      const entry = {
        event: 'http_request',
        method,
        route,
        status,
        duration_ms: Math.round(durationMs * 100) / 100,
        slow,
      };
      const msg = `${method} ${route} ${status} ${entry.duration_ms}ms`;
      if (status >= 500) logger.error(entry, msg);
      else if (status >= 400 || slow) logger.warn(entry, msg);
      else logger.info(entry, msg);
    };

    res.on('finish', () => finish(false));
    res.on('close', () => finish(!res.writableFinished));
    next();
  };
}

module.exports = { createHttpMetrics, httpObservabilityMiddleware, routeOf, DURATION_BUCKETS_SECONDS };
