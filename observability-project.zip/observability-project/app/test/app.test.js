'use strict';

/**
 * Tests d'intégration de l'API (sans infrastructure d'observabilité).
 * Lancement : npm test
 */

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { Writable } = require('node:stream');
const pino = require('pino');
const { createApiApp } = require('../src/app');
const { createInventoryApp } = require('../src/inventory');

const silentLogger = pino({ level: 'silent' }, new Writable({ write(_c, _e, cb) { cb(); } }));

function listen(app) {
  return new Promise((resolve) => {
    const server = app.listen(0, '127.0.0.1', () => resolve(server));
  });
}

const baseConfig = {
  slowThresholdMs: 1000,
  slowMinDelayMs: 10,
  slowMaxDelayMs: 20,
  maxSlowDelayMs: 5000,
  upstreamTimeoutMs: 1000,
  inventoryFailureRate: 0,
};

let inventoryServer;
let apiServer;
let brokenApiServer;
let base;
let brokenBase;

before(async () => {
  inventoryServer = await listen(createInventoryApp({
    config: { ...baseConfig, serviceName: 'inventory-test' },
    logger: silentLogger,
  }));
  const inventoryUrl = `http://127.0.0.1:${inventoryServer.address().port}`;
  apiServer = await listen(createApiApp({
    config: { ...baseConfig, serviceName: 'api-test', inventoryUrl },
    logger: silentLogger,
  }));
  base = `http://127.0.0.1:${apiServer.address().port}`;
  // API pointant vers un inventory inexistant (port 9 = discard, fermé).
  brokenApiServer = await listen(createApiApp({
    config: { ...baseConfig, serviceName: 'api-broken', inventoryUrl: 'http://127.0.0.1:9' },
    logger: silentLogger,
  }));
  brokenBase = `http://127.0.0.1:${brokenApiServer.address().port}`;
});

after(() => {
  for (const s of [inventoryServer, apiServer, brokenApiServer]) s?.close();
});

test('GET / présente l\'API', async () => {
  const res = await fetch(`${base}/`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(body.endpoints['GET /health']);
  assert.equal(res.headers.get('x-powered-by'), null);
});

test('GET /health renvoie ok', async () => {
  const res = await fetch(`${base}/health`);
  assert.equal(res.status, 200);
  assert.equal((await res.json()).status, 'ok');
});

test('GET /api/users renvoie des utilisateurs avec e-mails masqués', async () => {
  const res = await fetch(`${base}/api/users`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.count, 5);
  for (const u of body.data) {
    assert.match(u.email, /^.\*\*\*@example\.com$/);
    assert.match(u.lastName, /^.\.$/);
  }
});

test('GET /api/products agrège le stock du service inventory', async () => {
  const res = await fetch(`${base}/api/products`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.count, 5);
  const screen = body.data.find((p) => p.sku === 'MON-002');
  assert.equal(screen.stock, 0);
  assert.equal(screen.available, false);
});

test('GET /api/products renvoie 502 générique si inventory est indisponible', async () => {
  const res = await fetch(`${brokenBase}/api/products`);
  assert.equal(res.status, 502);
  const body = await res.json();
  assert.equal(body.error.code, 'UPSTREAM_UNAVAILABLE');
  assert.doesNotMatch(JSON.stringify(body), /127\.0\.0\.1|ECONNREFUSED/);
});

test('GET /api/slow respecte le délai demandé', async () => {
  const t0 = Date.now();
  const res = await fetch(`${base}/api/slow?delay=300`);
  const elapsed = Date.now() - t0;
  assert.equal(res.status, 200);
  assert.equal((await res.json()).delayMs, 300);
  assert.ok(elapsed >= 290, `durée ${elapsed} ms`);
});

test('GET /api/slow rejette un délai invalide (400)', async () => {
  for (const d of ['abc', '-1', '999999']) {
    const res = await fetch(`${base}/api/slow?delay=${d}`);
    assert.equal(res.status, 400);
    assert.equal((await res.json()).error.code, 'INVALID_PARAMETER');
  }
});

test('GET /api/error renvoie 500 sans fuite d\'information interne', async () => {
  const res = await fetch(`${base}/api/error`);
  assert.equal(res.status, 500);
  const text = await res.text();
  const body = JSON.parse(text);
  assert.equal(body.error.code, 'SIMULATED_FAILURE');
  assert.equal(body.error.message, 'Une erreur interne est survenue.');
  assert.doesNotMatch(text, /db-primary|5432|at .*\.js|stack/i);
});

test('GET /api/error?code=503 renvoie le code demandé (liste blanche)', async () => {
  assert.equal((await fetch(`${base}/api/error?code=503`)).status, 503);
  assert.equal((await fetch(`${base}/api/error?code=418`)).status, 500);
});

test('Route inconnue -> 404 JSON', async () => {
  const res = await fetch(`${base}/does-not-exist`);
  assert.equal(res.status, 404);
  assert.equal((await res.json()).error.code, 'NOT_FOUND');
});
