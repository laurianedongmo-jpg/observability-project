# Plateforme d'observabilité d'une application avec OpenTelemetry Collector, Prometheus et Grafana

Projet complet et exécutable : une API Node.js/Express (deux microservices) instrumentée avec **OpenTelemetry**, dont les **métriques**, **traces** et **logs** transitent par **OpenTelemetry Collector** avant d'être stockés dans **Prometheus**, **Jaeger** et **Loki**, puis visualisés dans **Grafana**. L'ensemble démarre avec une seule commande Docker Compose.

---

## Sommaire

1. [Présentation](#1-présentation)
2. [Contexte et problématique](#2-contexte-et-problématique)
3. [Objectifs](#3-objectifs)
4. [Notions clés (pédagogie)](#4-notions-clés-pédagogie)
5. [Architecture technique](#5-architecture-technique)
6. [Rôle de chaque technologie et versions](#6-rôle-de-chaque-technologie-et-versions)
7. [Structure du projet](#7-structure-du-projet)
8. [L'application et son instrumentation](#8-lapplication-et-son-instrumentation)
9. [Configuration d'OpenTelemetry Collector expliquée](#9-configuration-dopentelemetry-collector-expliquée)
10. [Prometheus, Jaeger, Loki, Grafana](#10-prometheus-jaeger-loki-grafana)
11. [Prérequis](#11-prérequis)
12. [Installation, démarrage, arrêt](#12-installation-démarrage-arrêt)
13. [URL et ports](#13-url-et-ports)
14. [Tests et validation](#14-tests-et-validation)
15. [Diagnostic des erreurs courantes](#15-diagnostic-des-erreurs-courantes)
16. [Sécurité](#16-sécurité)
17. [Limites du projet](#17-limites-du-projet)
18. [Pistes d'amélioration pour la production](#18-pistes-damélioration-pour-la-production)
19. [État de validation](#19-état-de-validation)

---

## 1. Présentation

Le projet met en place une chaîne d'observabilité de bout en bout :

- une **API REST** (`demo-api`) qui expose des utilisateurs et des produits fictifs, simule des lenteurs et des erreurs ;
- un second service (`inventory-service`) appelé par l'API pour fournir le stock, afin d'obtenir de **véritables traces distribuées** (une requête = une trace traversant deux services) ;
- un **OpenTelemetry Collector** qui reçoit toute la télémétrie, la traite et la route ;
- **Prometheus** (métriques), **Jaeger** (traces), **Loki** (logs) comme backends de stockage ;
- **Grafana**, provisionné automatiquement avec ses sources de données et un tableau de bord prêt à l'emploi ;
- une **suite de tests de bout en bout** qui vérifie chaque flux.

## 2. Contexte et problématique

Une application en production peut ralentir ou échouer sans que l'on sache **où**, **quand** ni **pourquoi**. Les logs dispersés sur plusieurs machines, l'absence de mesures de latence ou la difficulté à suivre une requête à travers plusieurs services rendent le diagnostic long et incertain.

La problématique est donc : **comment collecter, de manière standardisée et indépendante des fournisseurs, les signaux de télémétrie d'une application, les centraliser et les rendre exploitables pour détecter et expliquer les problèmes de performance et les erreurs ?**

OpenTelemetry répond à la partie « standardisation » (un seul SDK, un seul protocole, OTLP), le Collector à la partie « centralisation et routage », et la pile Prometheus/Jaeger/Loki/Grafana à la partie « stockage et exploitation ».

## 3. Objectifs

**Objectif général** : mettre en place une plateforme d'observabilité complète, reproductible et sécurisée par défaut, pour une application web.

**Objectifs spécifiques** :

| # | Objectif | Réalisation |
|---|----------|-------------|
| 1 | Collecter les métriques de l'application | SDK OTel → Collector → Prometheus |
| 2 | Collecter et analyser les traces distribuées | SDK OTel → Collector → Jaeger, propagation W3C entre 2 services |
| 3 | Collecter les logs | pino + instrumentation OTel → Collector → Loki |
| 4 | Mesurer les temps de réponse | histogrammes `app_http_request_duration_seconds` et `http_server_request_duration_seconds` |
| 5 | Surveiller requêtes et erreurs HTTP | compteur `app_http_requests_total` par route et code de statut |
| 6 | Visualiser | tableau de bord Grafana provisionné (38 éléments) |
| 7 | Identifier les problèmes de performance | percentiles, latence par route, requêtes lentes, corrélation logs ↔ traces |
| 8 | Simuler erreurs et ralentissements | routes `/api/error`, `/api/slow`, panne aléatoire d'`inventory` |

## 4. Notions clés (pédagogie)

**Observabilité** — capacité à comprendre l'état interne d'un système à partir des données qu'il émet, y compris pour des problèmes que l'on n'avait pas prévus. La surveillance (monitoring) répond à « est-ce que ça marche ? » ; l'observabilité répond aussi à « pourquoi ça ne marche pas ? ». Elle repose sur trois signaux complémentaires :

| Signal | Question | Forme | Exemple dans ce projet | Stockage |
|--------|----------|-------|------------------------|----------|
| **Métrique** | *Combien ? À quelle vitesse ?* | valeur numérique agrégée dans le temps, peu coûteuse | `app_http_requests_total{http_route="/api/users",http_response_status_code="200"} 42` | Prometheus |
| **Trace** | *Où le temps est-il passé pour CETTE requête ?* | arbre de *spans* (opérations chronométrées) reliés par un `trace_id` | `GET /api/products` → `db.query products` → `GET` (fetch) → `GET /inventory/stock` → `cache.lookup stock` | Jaeger |
| **Log** | *Que s'est-il passé exactement ?* | événement horodaté, texte ou JSON structuré | `{"level":"error","msg":"Erreur 500 (SIMULATED_FAILURE)...","trace_id":"d45c..."}` | Loki |

- Une **métrique** dit qu'il y a un problème (le taux d'erreurs monte).
- Une **trace** dit où il se situe (quel service, quelle opération).
- Un **log** dit ce qui s'est passé (message d'erreur, contexte).
- Le **`trace_id`** présent dans les logs et dans les traces permet de passer de l'un à l'autre (corrélation).

**Instrumentation** — ajout dans l'application du code qui produit la télémétrie.
- *Automatique* : des bibliothèques OpenTelemetry interceptent `http`, `express`, `fetch` (undici), `pino` et créent spans, métriques et enrichissement des logs sans modifier le code métier.
- *Manuelle* : le code crée explicitement des spans (`db.query users`, `simulate.slow_operation`) et des métriques métier (`app.http.slow_requests`).

**OpenTelemetry (OTel)** — standard ouvert (CNCF) composé d'une API, de SDK par langage, d'un protocole (**OTLP**) et du **Collector**. Il découple la production de télémétrie du choix des outils de stockage.

**Push vs Pull** — l'application **pousse** (push) sa télémétrie au Collector en OTLP ; Prometheus **tire** (pull/scrape) les métriques exposées par le Collector. Ce sont deux mécanismes distincts à ne pas confondre (voir §5).

## 5. Architecture technique

```
                 ┌───────────────────────── réseau app-net ─────────────────────────┐
  Navigateur /   │                                                                   │
  curl ──8080──► │  demo-api (Express)  ──HTTP + traceparent──►  inventory-service   │
                 │        │  SDK OTel                                    │ SDK OTel   │
                 │        └──────────── OTLP/HTTP (protobuf) :4318 ──────┘            │
                 │                              ▼                                     │
                 │                 ┌──────────────────────────┐                       │
                 └─────────────────┤  OpenTelemetry Collector ├───────────────────────┘
                                   │ receivers → processors → │
                 ┌─────────────────┤        exporters         ├─────────────────────┐
                 │                 └──┬─────────┬──────────┬──┘   réseau obs-net    │
                 │      traces        │ métriques│     logs │                       │
                 │  OTLP/gRPC :4317   │ expose   │ OTLP/HTTP│                       │
                 │                    ▼ :8889    │  /otlp   ▼                       │
                 │               ┌────────┐      │     ┌────────┐                   │
                 │               │ Jaeger │   scrape   │  Loki  │                   │
                 │               │ Badger │◄─┐ (pull)  └───┬────┘                   │
                 │               └───┬────┘  │  ┌───────────┴┐                       │
                 │                   │       └──┤ Prometheus │                       │
                 │                   │          └─────┬──────┘                       │
                 │                   └────────┐       │      ┌─────────┘             │
                 │                            ▼       ▼      ▼                       │
                 │                         ┌────────────────────┐                    │
                 │                         │      Grafana       │ ◄──3000── utilisateur
                 │                         └────────────────────┘                    │
                 └────────────────────────────────────────────────────────────────────┘
```

### Chemin de chaque signal

| Signal | Chemin complet | Protocole / mode |
|--------|----------------|------------------|
| **Traces** | SDK Node → `otel-collector:4318` (receiver `otlp`) → `memory_limiter` → `resource` → `attributes/scrub` → `batch` → exporter `otlp_grpc/jaeger` → `jaeger:4317` → stockage Badger → UI Jaeger `:16686` / Grafana (source Jaeger) | **push** OTLP/HTTP puis OTLP/gRPC |
| **Métriques** | SDK Node (export toutes les 10 s) → `otel-collector:4318` → `memory_limiter` → `resource` → `batch` → exporter `prometheus` qui **expose** `otel-collector:8889/metrics` ← **Prometheus scrape toutes les 15 s** → TSDB → Grafana (source Prometheus) | **push** OTLP jusqu'au Collector, puis **pull** par Prometheus |
| **Logs** | pino (stdout + SDK Logs via instrumentation) → `otel-collector:4318` → `memory_limiter` → `resource` → `attributes/scrub` → `batch` → exporter `otlp_http/loki` → `loki:3100/otlp/v1/logs` → Grafana (source Loki) | **push** OTLP/HTTP |
| Santé des services | receiver `http_check` du Collector interroge les `/health` → pipeline métriques → Prometheus | sonde active |
| Télémétrie interne du Collector | `otel-collector:8888/metrics` ← scrape Prometheus | pull |

### Distinction Collector / Prometheus

- Le **Collector** *traite* et *route* : il ne stocke rien. Il reçoit l'OTLP, applique les processors, convertit les métriques au format Prometheus et les **met à disposition** sur `:8889`.
- **Prometheus** *collecte et stocke* : il vient lire (`scrape`) cet endpoint selon `prometheus/prometheus.yml` et conserve les séries 15 jours.
- L'application **n'expose pas** d'endpoint `/metrics` : ce n'est pas nécessaire avec cette architecture (les métriques sont poussées en OTLP). Un `GET /metrics` sur l'API renvoie donc 404, volontairement.

### Justification des choix

| Choix | Justification |
|-------|---------------|
| Collector en point d'entrée unique | découple l'application des backends : changer Jaeger pour Tempo ne touche pas au code ; nettoyage des données sensibles et regroupement centralisés |
| OTLP/HTTP (protobuf) côté application | protocole par défaut du SDK Node, sans dépendance gRPC native, compressible, traverse facilement les proxys |
| Exporter `prometheus` (pull) plutôt que remote-write | conserve le modèle natif de Prometheus (cibles, `up`, alertes de scrape) et rend explicite la séparation traitement/stockage demandée |
| Jaeger v2 | construit sur le Collector OTel, reçoit l'OTLP nativement (plus d'agent Jaeger), Jaeger v1 n'est plus supporté depuis fin 2025 |
| Loki 3 via OTLP natif | l'ancien exporter `loki` du Collector est déprécié ; l'endpoint `/otlp` de Loki 3 conserve les attributs en *structured metadata* (dont `trace_id`) |
| Deux services Node.js | une trace distribuée réelle, avec propagation du contexte W3C `traceparent` |
| Métriques applicatives + métriques standard | `app_http_*` (contrôle total des labels, compteur de requêtes lentes) et `http_server_request_duration_seconds` (convention sémantique OTel stable) |
| Configuration du SDK par variables `OTEL_*` | standard OpenTelemetry, modifiable sans recompiler l'image |

## 6. Rôle de chaque technologie et versions

Toutes les images sont épinglées à une version précise (vérifiée en octobre 2026) pour garantir la reproductibilité.

| Composant | Version | Rôle |
|-----------|---------|------|
| Node.js | `node:22.22.0-bookworm-slim` | exécution de l'API (LTS) |
| Express | 5.3.0 | framework HTTP |
| pino | 10.4.0 | logs JSON structurés |
| OpenTelemetry JS SDK | `@opentelemetry/sdk-node` 0.223.0 (API 1.9.1) | génération et export OTLP des traces, métriques, logs |
| Instrumentations OTel | http 0.223.0, express 0.71.1, undici 0.33.0, pino 0.69.0, runtime-node 0.36.1 | instrumentation automatique |
| OpenTelemetry Collector | `otel/opentelemetry-collector-contrib:0.162.0` | réception, traitement, routage |
| Prometheus | `prom/prometheus:v3.13.4` (branche LTS) | scrape et stockage des métriques, règles d'alerte |
| Jaeger | `jaegertracing/jaeger:2.22.0` | stockage (Badger) et visualisation des traces |
| Loki | `grafana/loki:3.7.8` | stockage et requêtage des logs (LogQL) |
| Grafana | `grafana/grafana:12.4.13` | tableaux de bord, exploration, corrélation |
| BusyBox | `busybox:1.37.0` | conteneur d'initialisation des droits du volume Jaeger |

La distribution **contrib** du Collector est choisie car elle contient tous les composants utilisés : `otlp` (receiver), `http_check` (receiver), `memory_limiter`, `batch`, `resource`, `attributes` (processors), `otlp_grpc`, `otlp_http`, `prometheus`, `debug` (exporters), `health_check` (extension). La distribution « core » ne contient ni l'exporter `prometheus` ni `http_check`.

## 7. Structure du projet

```
observability-project/
├── app/                                  # Application Node.js (image commune aux 2 services)
│   ├── src/
│   │   ├── instrumentation.js            # Initialisation du SDK OpenTelemetry (chargé avec --require)
│   │   ├── server.js                     # Point d'entrée, choix du rôle api/inventory, arrêt propre
│   │   ├── app.js                        # Routes du service demo-api
│   │   ├── inventory.js                  # Routes du service inventory-service
│   │   ├── telemetry.js                  # Métriques HTTP applicatives + middleware de mesure/log d'accès
│   │   ├── tracing.js                    # Utilitaire de création de spans manuels
│   │   ├── errors.js                     # Gestion centralisée des erreurs (sans fuite d'information)
│   │   ├── logger.js                     # Logger pino (JSON, masquage des champs sensibles)
│   │   ├── config.js                     # Lecture et validation des variables d'environnement
│   │   └── data.js                       # Données fictives (e-mails masqués)
│   ├── test/app.test.js                  # Tests d'intégration de l'API (node:test)
│   ├── package.json / package-lock.json  # Dépendances épinglées
│   ├── Dockerfile                        # Multi-étapes, utilisateur non-root, HEALTHCHECK
│   └── .dockerignore
├── otel-collector/config.yaml            # Receivers, processors, exporters, pipelines, télémétrie interne
├── prometheus/
│   ├── prometheus.yml                    # Cibles de scrape
│   └── rules/alerts.yml                  # Règles d'alerte (erreurs, latence, cibles down)
├── jaeger/config.yaml                    # Jaeger v2 : OTLP, stockage Badger, UI
├── loki/config.yaml                      # Loki monolithique, stockage local, rétention 7 j
├── grafana/
│   ├── provisioning/datasources/datasources.yaml   # Prometheus, Loki, Jaeger + corrélations
│   ├── provisioning/dashboards/dashboards.yaml     # Fournisseur de tableaux de bord
│   └── dashboards/observability-overview.json      # Tableau de bord principal
├── tests/
│   ├── e2e.mjs                           # Test de bout en bout automatisé (aucune dépendance)
│   ├── smoke.sh                          # Vérifications rapides avec curl
│   └── generate-traffic.sh               # Générateur de trafic continu
├── compose.yaml                          # Orchestration complète
├── .env.example                          # Modèle de configuration (à copier en .env)
├── .gitignore
└── README.md
```

## 8. L'application et son instrumentation

### Routes

| Route | Service | Description | Codes |
|-------|---------|-------------|-------|
| `GET /` | api | présentation de l'API et liste des routes | 200 |
| `GET /health` | api, inventory | état du service (exclu des traces) | 200 |
| `GET /api/users` | api | 5 utilisateurs fictifs, nom et e-mail **masqués** ; span enfant `db.query users` | 200 |
| `GET /api/products` | api | 5 produits + stock obtenu par appel HTTP à `inventory` (trace distribuée) | 200, 502, 504 |
| `GET /api/slow?delay=<ms>` | api | lenteur simulée (défaut aléatoire 1–3 s, max 5 s) ; span `simulate.slow_operation` | 200, 400 |
| `GET /api/error?code=<500\|502\|503\|504>` | api | erreur simulée (défaut 500), exception enregistrée dans la trace | 5xx |
| `GET /inventory/stock` | inventory | stock par SKU ; panne aléatoire si `INVENTORY_FAILURE_RATE > 0` | 200, 503 |
| toute autre route | api, inventory | réponse JSON 404 | 404 |
| `GET /metrics` | — | **non implémenté volontairement** (métriques poussées en OTLP) | 404 |

Exemple de réponse d'erreur (aucune pile d'appel, aucun détail interne ; le `traceId` permet au support de retrouver la trace et les logs) :

```json
{"error":{"code":"SIMULATED_FAILURE","message":"Une erreur interne est survenue."},"traceId":"d45cb59e57448875c1ed4485e3d254ea"}
```

### Instrumentation

`app/src/instrumentation.js` est chargé **avant** le code applicatif (`node --require ./src/instrumentation.js src/server.js`), condition nécessaire pour que les modules `http`, `express`, `undici` et `pino` soient instrumentés.

| Instrumentation | Produit |
|-----------------|---------|
| `instrumentation-http` | span serveur par requête (`GET /api/users`), métriques `http.server.request.duration` / `http.client.request.duration` (conventions stables via `OTEL_SEMCONV_STABILITY_OPT_IN=http`) ; `/health` exclu |
| `instrumentation-express` | span par handler de route (`request handler - /api/users`) et attribut `http.route` ; spans de middlewares désactivés (bruit) |
| `instrumentation-undici` | span client pour `fetch()` et injection de l'en-tête `traceparent` → la trace continue dans `inventory-service` |
| `instrumentation-pino` | ajoute `trace_id`, `span_id`, `trace_flags` à chaque log **et** transmet les logs au SDK Logs OTel |
| `instrumentation-runtime-node` | boucle d'événements, heap V8, GC |
| manuel (`tracing.js`) | spans métier : `db.query users`, `db.query products`, `cache.lookup stock`, `simulate.slow_operation`, `simulate.failing_operation` |

### Métriques produites (noms côté Prometheus)

| Métrique | Type | Labels principaux | Usage |
|----------|------|-------------------|-------|
| `app_http_requests_total` | counter | `http_route`, `http_request_method`, `http_response_status_code`, `http_response_status_class`, `job` | débit, taux d'erreurs, répartition des codes |
| `app_http_request_duration_seconds_{bucket,sum,count}` | histogram (5 ms → 10 s) | idem | moyenne, p50/p90/p95/p99 |
| `app_http_slow_requests_total` | counter | `http_route`, `http_request_method` | requêtes > `SLOW_REQUEST_THRESHOLD_MS` (1 s) |
| `app_http_active_requests` | gauge | `http_request_method` | requêtes en cours |
| `http_server_request_duration_seconds_*` | histogram | convention OTel | métrique standard (auto) |
| `http_client_request_duration_seconds_*` | histogram | convention OTel | appels api → inventory |
| `nodejs_eventloop_*`, `v8js_*` | divers | — | santé du runtime |
| `httpcheck_status` | gauge | `http_url`, `http_status_class` | état des services (sonde du Collector) |
| `target_info` | gauge | attributs de ressource | métadonnées des services |

Le label `job` vaut le nom du service fourni par la ressource OTel (avec le namespace, par exemple `observability-demo/demo-api`) ; c'est pourquoi les requêtes utilisent `job=~".*demo-api"` et que le tableau de bord propose une variable `job`.

La conversion des noms OTel vers Prometheus est faite par l'exporter `prometheus` du Collector : les points deviennent des `_`, l'unité `s` ajoute `_seconds`, les compteurs reçoivent `_total`, les unités entre accolades (`{request}`) sont ignorées.

## 9. Configuration d'OpenTelemetry Collector expliquée

Fichier : [`otel-collector/config.yaml`](otel-collector/config.yaml). Un composant n'est actif **que s'il est référencé** dans `service`.

### `extensions`
- `health_check` sur `0.0.0.0:13133` : répond 200 quand le Collector est prêt. L'image du Collector est *distroless* (pas de shell) : un `HEALTHCHECK` Docker interne est impossible, la sonde est donc interrogée depuis l'extérieur (tests, `curl`).

### `receivers`
- `otlp` : gRPC `0.0.0.0:4317` et HTTP `0.0.0.0:4318`. **Important** : depuis la v0.110 l'adresse par défaut est `localhost`, injoignable depuis les autres conteneurs ; il faut écouter explicitement sur `0.0.0.0`.
- `http_check` : sonde toutes les 15 s les endpoints de santé de l'api, d'inventory, de Jaeger, Loki, Prometheus et Grafana et produit `httpcheck.status`. (Nom actuel du receiver ; l'ancien nom `httpcheck` reste un alias déprécié.)

### `processors` (ordre = ordre d'exécution dans le pipeline)
1. `memory_limiter` : vérifie la mémoire chaque seconde ; au-delà de 80 % de la limite du conteneur (512 Mo), refuse temporairement les données (le SDK réessaie) au lieu de se faire tuer par le noyau. Toujours **en premier**.
2. `resource` : ajoute `deployment.environment.name` à toute la télémétrie.
3. `attributes/scrub` : supprime les en-têtes `authorization`/`cookie`, `user.email`, `client.address` (adresse IP) et hache `enduser.id` s'ils apparaissent (défense en profondeur RGPD). Appliqué aux traces et aux logs.
4. `batch` : regroupe jusqu'à 1024 éléments (max 2048) ou attend 5 s : moins d'appels réseau. Toujours **en dernier**.

### `exporters`
- `otlp_grpc/jaeger` → `jaeger:4317`, TLS désactivé (réseau Docker interne), file d'attente de 1000 lots et réessais exponentiels (5 s → 30 s, abandon après 5 min). `otlp_grpc` est le nom actuel de l'ancien `otlp` (renommé en v0.144).
- `prometheus` → expose `0.0.0.0:8889/metrics`. `metric_expiration: 5m` retire les séries inactives ; `enable_open_metrics: true` permet les exemplars ; `resource_constant_labels` recopie seulement `deployment.environment.name` en label (les autres attributs de ressource restent dans `target_info`, pour limiter la cardinalité).
- `otlp_http/loki` → `http://loki:3100/otlp` (le chemin `/v1/logs` est ajouté automatiquement). Ancien nom : `otlphttp`.
- `debug` (verbosité `basic`) : résumé des lots de traces dans les logs du Collector, utile au diagnostic.

### `service.pipelines`

| Pipeline | Receivers | Processors | Exporters |
|----------|-----------|------------|-----------|
| `traces` | otlp | memory_limiter, resource, attributes/scrub, batch | otlp_grpc/jaeger, debug |
| `metrics` | otlp, http_check | memory_limiter, resource, batch | prometheus |
| `logs` | otlp | memory_limiter, resource, attributes/scrub, batch | otlp_http/loki |

### `service.telemetry` (télémétrie interne)
- `logs.level: info` ;
- `metrics.level: detailed` exposées en Prometheus sur `0.0.0.0:8888` via un *reader* `pull`. Prometheus les collecte (job `otel-collector`) et le tableau de bord en affiche le débit reçu/exporté, les échecs, les files d'attente, la mémoire et le CPU.

## 10. Prometheus, Jaeger, Loki, Grafana

**Prometheus** (`prometheus/prometheus.yml`) — scrape toutes les 15 s : `otel-collector:8889` (métriques applicatives, `honor_labels: true` pour conserver le `job` = nom du service), `otel-collector:8888` (Collector), `jaeger:8888`, `loki:3100`, `grafana:3000`, lui-même. Rétention 15 jours (`PROMETHEUS_RETENTION`). Règles d'alerte (`prometheus/rules/alerts.yml`) : taux de 5xx > 5 %, p95 > 1 s, cible down, sonde de santé en échec, échecs d'export du Collector. Visibles sur <http://localhost:9090/alerts> (pas d'Alertmanager : pas de notification).

**Jaeger** (`jaeger/config.yaml`) — Jaeger v2 reçoit l'OTLP sur 4317/4318 (non publiés sur l'hôte : seul le Collector lui envoie des traces), stocke dans **Badger** sur le volume `jaeger-data` (rétention 72 h), sert l'UI et l'API sur 16686 et sa santé sur 13133 (`/status`). Le service `jaeger-init` attribue le volume à l'UID 10001 utilisé par l'image Jaeger.

**Loki** (`loki/config.yaml`) — mode monolithique, schéma `v13`/`tsdb` (requis pour OTLP), stockage fichier sur `loki-data`, rétention 7 jours via le compacteur, `allow_structured_metadata: true` (indispensable à l'ingestion OTLP). Labels indexés : `service_name`, `service_namespace`, `deployment_environment`… ; les autres attributs (`trace_id`, `span_id`, `severity_text`, `route`, `status`…) sont en *structured metadata*, filtrables : `{service_name="demo-api"} | severity_text="error"`.

**Grafana** — provisionné au démarrage :
- sources `Prometheus` (uid `prometheus`, par défaut), `Loki` (uid `loki`), `Jaeger` (uid `jaeger`) ;
- **corrélation logs → traces** : champ dérivé `TraceID` sur le `trace_id` des logs Loki, lien direct vers Jaeger ;
- **corrélation traces → logs** : depuis un span dans Grafana, bouton « Logs for this span » qui interroge Loki sur le même `trace_id` ;
- tableau de bord **« Observabilité - Demo API »** (dossier *Observabilité*, page d'accueil par défaut) :

| Section | Panneaux |
|---------|----------|
| Vue d'ensemble (RED) | requêtes sur la période, débit, taux d'erreurs 5xx, latence p95, requêtes lentes, services en ligne |
| Trafic HTTP | débit par route, réponses par classe de statut (2xx/4xx/5xx), répartition des codes, taux d'erreurs par route, requêtes en cours |
| Temps de réponse | moyenne + p50/p90/p95/p99, p95 par route, requêtes lentes par route, heatmap de distribution |
| État des services | sondes `http_check` (UP/DOWN dans le temps), table des cibles Prometheus (`up`) |
| OpenTelemetry Collector | données reçues, exportées/en échec/refusées, files d'attente, mémoire RSS, CPU, taille des lots |
| Runtime Node.js | utilisation de la boucle d'événements, heap V8 |
| Traces (Jaeger) | traces récentes, traces en erreur (`error=true`) — cliquer sur un Trace ID |
| Logs (Loki) | volume par niveau, tous les logs, logs d'erreur — détail d'une ligne → lien vers la trace |

## 11. Prérequis

| Logiciel | Version minimale | Vérification |
|----------|------------------|--------------|
| Docker Engine (ou Docker Desktop) | 24+ | `docker version` |
| Docker Compose v2 | 2.24+ | `docker compose version` |
| Ressources | 4 Go de RAM libres, 3 Go de disque | — |
| curl (facultatif, pour `smoke.sh`) | — | `curl --version` |
| Node.js 22 (facultatif, tests unitaires hors Docker) | 22 | `node -v` |

Ports libres sur l'hôte : 8080, 3000, 9090, 16686, 3100, 4317, 4318, 13133 (modifiables pour l'API et Grafana dans `.env`).

Architecture : toutes les images utilisées sont publiées pour `amd64` et `arm64` (Apple Silicon compatible).

## 12. Installation, démarrage, arrêt

```bash
# 1. Récupérer le projet puis se placer dans le dossier
cd observability-project

# 2. Créer la configuration locale et choisir un mot de passe Grafana
cp .env.example .env
#    (éditer .env : GRAFANA_ADMIN_PASSWORD=...)

# 3. Construire l'image de l'application et démarrer toute la pile
docker compose up -d --build

# 4. Vérifier l'état (api, inventory, prometheus, grafana doivent être "healthy" ;
#    jaeger-init "exited (0)" est normal)
docker compose ps
```

| Action | Commande |
|--------|----------|
| Suivre les logs de tous les services | `docker compose logs -f` |
| Logs d'un service | `docker compose logs -f otel-collector` |
| Redémarrer un service après modification de sa config | `docker compose restart otel-collector` |
| Reconstruire l'application après modification du code | `docker compose up -d --build api inventory` |
| Arrêter (données conservées) | `docker compose down` |
| Arrêter et **effacer** toutes les données (volumes) | `docker compose down -v` |
| Activer des pannes aléatoires d'inventory (20 %) | `INVENTORY_FAILURE_RATE=0.2 docker compose up -d inventory` |

Le premier démarrage télécharge environ 1,5 Go d'images.

## 13. URL et ports

Tous les ports sont publiés sur **127.0.0.1** uniquement (variable `BIND_ADDRESS`).

| Interface | URL | Accès |
|-----------|-----|-------|
| API demo-api | <http://localhost:8080> | public (local) |
| Grafana | <http://localhost:3000> | `admin` / mot de passe du `.env` |
| Prometheus | <http://localhost:9090> | sans authentification (local) |
| Jaeger UI | <http://localhost:16686> | sans authentification (local) |
| Loki API | <http://localhost:3100> (pas d'UI : utiliser Grafana → Explore) | local |
| Collector — santé | <http://localhost:13133/> | local |
| Collector — OTLP | `localhost:4317` (gRPC), `localhost:4318` (HTTP) | pour lancer l'app hors Docker |

Ports **internes** (non publiés) : `inventory:8081`, `otel-collector:8888` (métriques internes) et `:8889` (métriques applicatives), `jaeger:4317/4318/8888/13133`.

## 14. Tests et validation

### 14.1 Tests unitaires/intégration de l'API (sans infrastructure)

```bash
cd app && npm ci && npm test
```
Résultat attendu : `# pass 10  # fail 0` (routes, masquage des e-mails, appel inventory, 502 si inventory indisponible, lenteur, validation du paramètre `delay`, erreur sans fuite d'information, liste blanche de codes, 404).

### 14.2 Test de bout en bout automatisé (recommandé)

```bash
docker compose up -d --build
docker compose --profile test run --rm e2e
```
Le conteneur `e2e` (Node 22, aucune dépendance) se connecte aux deux réseaux Docker et vérifie 34 points. Sortie attendue (extrait) :

```
== 1. Disponibilité des composants ==
PASS API /health -> HTTP 200 {status: ok}
PASS OpenTelemetry Collector (health_check :13133) -> HTTP 200
...
== 3. Métriques dans Prometheus (App -> OTLP -> Collector :8889 <- scrape Prometheus) ==
PASS Compteur app_http_requests_total (routes /api/users) -> 20 requêtes
PASS Erreurs 5xx comptabilisées -> 10 réponses 5xx
PASS Histogramme de durée + percentile p95 calculable -> p95(/api/slow) = 2.38 s
...
== 4. Traces dans Jaeger ==
PASS Trace distribuée GET /api/products (demo-api -> inventory-service) -> trace 921c…: 6 spans, services = demo-api + inventory-service
...
== Résultat : 34/34 vérifications réussies ==
```
Code de sortie 0 si tout réussit, 1 sinon (utilisable en CI). Les étapes de vérification réessaient pendant 120 s (`E2E_TIMEOUT_MS`), le temps que les métriques traversent export (10 s) + scrape (15 s). Lancé une seconde fois, les compteurs sont simplement plus élevés (les assertions utilisent des minimums).

Alternative depuis l'hôte : `GRAFANA_PASSWORD=<mot de passe> node tests/e2e.mjs`.

### 14.3 Vérifications manuelles pas à pas

**a) Disponibilité de l'API**
```bash
curl -i http://localhost:8080/health
```
Attendu : `HTTP/1.1 200 OK` et `{"status":"ok","service":"demo-api","uptimeSeconds":...}`.

**b) Générer des métriques**
```bash
for i in $(seq 1 30); do curl -s -o /dev/null -w "%{http_code} " http://localhost:8080/api/users; done; echo
curl -s http://localhost:8080/api/products | head -c 300; echo
```
Attendu : trente `200`, puis la liste des produits avec un champ `stock`.

**c) Simuler des lenteurs**
```bash
curl -s -w "\ndurée totale : %{time_total}s\n" "http://localhost:8080/api/slow?delay=2500"
for i in 1 2 3; do curl -s -o /dev/null http://localhost:8080/api/slow; done
```
Attendu : `{"message":"Réponse lente simulée","delayMs":2500}` et une durée ≈ 2,5 s. Chaque requête dépasse le seuil de 1 s : `app_http_slow_requests_total` augmente.

**d) Simuler des erreurs**
```bash
curl -i http://localhost:8080/api/error
curl -s -o /dev/null -w "%{http_code}\n" "http://localhost:8080/api/error?code=503"
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8080/route-inconnue
```
Attendu : `500` avec un message générique et un `traceId` (aucune pile d'appel, aucun nom d'hôte interne), puis `503`, puis `404`.

**e) Vérifier les métriques dans Prometheus** (attendre ~25 s)
```bash
curl -s 'http://localhost:9090/api/v1/query' --data-urlencode 'query=sum by (http_route, http_response_status_code) (app_http_requests_total)'
curl -s 'http://localhost:9090/api/v1/query' --data-urlencode 'query=histogram_quantile(0.95, sum by (le) (rate(app_http_request_duration_seconds_bucket[5m])))'
curl -s 'http://localhost:9090/api/v1/query' --data-urlencode 'query=up'
```
Attendu : `"status":"success"` et des séries par route/code ; une valeur de p95 en secondes ; toutes les cibles à `"1"`. Dans l'interface : <http://localhost:9090/targets> → toutes les cibles **UP**.

**f) Vérifier les traces dans Jaeger**
```bash
curl -s http://localhost:16686/api/services
curl -s 'http://localhost:16686/api/traces?service=demo-api&operation=GET%20/api/products&limit=1' | head -c 600
```
Attendu : `{"data":["demo-api","inventory-service",...]}` puis une trace JSON. Dans l'UI <http://localhost:16686> : *Service* `demo-api` → *Find Traces*. Une trace `GET /api/products` contient les spans des **deux** services ; une trace `GET /api/error` est marquée en rouge, avec l'événement `exception` dans les *Logs* du span ; `GET /api/slow` montre un span `simulate.slow_operation` occupant presque toute la durée. Le `traceId` renvoyé par `/api/error` peut être collé dans la barre de recherche de Jaeger.

**g) Vérifier la collecte des logs dans Loki**
```bash
curl -s -G http://localhost:3100/loki/api/v1/query_range \
  --data-urlencode 'query={service_name="demo-api"} | severity_text="error"' \
  --data-urlencode 'limit=5'
curl -s http://localhost:3100/loki/api/v1/labels
```
Attendu : des entrées contenant `Erreur 500 (SIMULATED_FAILURE)` ; la liste de labels contient `service_name`. Dans Grafana → *Explore* → source *Loki* → `{service_name="demo-api"}` : déplier une ligne, le champ `trace_id` affiche le lien **« Voir la trace dans Jaeger »**.

**h) Vérifier Grafana**
```bash
curl -s -u admin:<mot_de_passe> http://localhost:3000/api/datasources | grep -o '"uid":"[a-z]*"'
curl -s -u admin:<mot_de_passe> http://localhost:3000/api/datasources/uid/prometheus/health
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:3000/api/dashboards/uid/obs-demo-overview
```
Attendu : les uid `prometheus`, `loki`, `jaeger` ; `"status":"OK"` ; `401` sans authentification (accès anonyme désactivé). Dans le navigateur : <http://localhost:3000>, le tableau de bord s'ouvre en page d'accueil ; lancer `./tests/generate-traffic.sh 300` pour voir les courbes évoluer.

**i) Vérifications rapides en une commande**
```bash
./tests/smoke.sh
```
Attendu : `Résultat : 14 réussis, 0 échoués.`

## 15. Diagnostic des erreurs courantes

**Méthode générale** : suivre le chemin de la donnée. `docker compose ps` → logs de l'application → logs du Collector → backend.

| Symptôme | Cause probable | Solution |
|----------|----------------|----------|
| `required variable GRAFANA_ADMIN_PASSWORD is missing` | pas de fichier `.env` | `cp .env.example .env` puis définir le mot de passe |
| `Bind for 127.0.0.1:3000 failed: port is already allocated` | port déjà utilisé | changer `GRAFANA_PORT`/`API_PORT` dans `.env`, ou libérer le port |
| Rien dans Jaeger/Prometheus/Loki ; logs de l'app : `OTLPExporterError ... ECONNREFUSED` | Collector arrêté ou mauvais endpoint | `docker compose logs otel-collector` ; vérifier `OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4318` (pas `localhost`) |
| Collector : `'...' has invalid keys` ou `unknown type` | faute de frappe ou composant absent de la distribution | vérifier l'indentation ; utiliser l'image **contrib** ; valider : `docker run --rm -v ./otel-collector/config.yaml:/c.yaml otel/opentelemetry-collector-contrib:0.162.0 validate --config=/c.yaml` |
| Collector : `alias is deprecated` | ancien nom de composant (`otlp`, `otlphttp`, `httpcheck`) | avertissement sans impact ; remplacer par `otlp_grpc`, `otlp_http`, `http_check` |
| Cible `otel-collector-app-metrics` DOWN dans Prometheus | Collector arrêté, ou exporter `prometheus` sans `0.0.0.0` | `curl` depuis Prometheus : `docker compose exec prometheus wget -qO- http://otel-collector:8889/metrics \| head` |
| Pas de métriques `app_*` alors que la cible est UP | aucune requête encore reçue, ou délai | envoyer du trafic, attendre ~25 s ; les séries inactives disparaissent après 5 min (`metric_expiration`) |
| Métriques présentes mais label `exported_job` au lieu de `job` | `honor_labels` absent | conserver `honor_labels: true` sur le job `otel-collector-app-metrics` |
| Jaeger redémarre en boucle : `permission denied` sur `/badger` | volume créé avant l'ajout de `jaeger-init` / droits incorrects | `docker compose down`, `docker volume rm observability-demo_jaeger-data`, `docker compose up -d` |
| Collector : `Exporting failed ... jaeger:4317 ... Unavailable` | Jaeger pas encore prêt | transitoire : les réessais (`retry_on_failure`) rattrapent ; sinon `docker compose logs jaeger` |
| Loki : HTTP 400 `structured metadata ... disabled` | `allow_structured_metadata: false` ou schéma < v13 | garder la config fournie (schéma v13 + `allow_structured_metadata: true`) |
| Loki : `entry too far behind` / `out of order` | horloge de l'hôte décalée | synchroniser l'heure (NTP) |
| Grafana : panneaux « No data » | intervalle de temps trop court ou pas de trafic | sélectionner *Last 15 minutes*, lancer `./tests/generate-traffic.sh 120` |
| Grafana : source de données en erreur | backend non démarré | Grafana → *Connections* → *Data sources* → *Test* ; `docker compose ps` |
| Collector `data refused due to high memory usage` | `memory_limiter` déclenché | augmenter `mem_limit` du Collector ou réduire le trafic ; observer le panneau « Mémoire du Collector » |
| `/api/products` renvoie 502 | `inventory` arrêté ou `INVENTORY_FAILURE_RATE` > 0 | `docker compose ps inventory` ; la trace Jaeger montre l'appel en échec |
| Pas de traces pour `/health` | comportement voulu | les sondes de santé sont exclues des traces (bruit) |
| Le build Docker échoue sur `npm ci` | `package-lock.json` absent ou désynchronisé | régénérer : `cd app && npm install` |

Commandes utiles :
```bash
docker compose ps                              # état et santé
docker compose logs --tail=100 otel-collector  # erreurs de réception/export
docker compose logs --tail=100 api             # logs JSON de l'application
curl -s http://localhost:13133/                # santé du Collector
docker compose exec prometheus wget -qO- http://otel-collector:8889/metrics | grep app_http | head
docker compose exec prometheus wget -qO- http://otel-collector:8888/metrics | grep otelcol_exporter_send_failed
```
Pour voir le contenu exact des traces dans les logs du Collector : passer `debug.verbosity` à `detailed` puis `docker compose restart otel-collector`.

## 16. Sécurité

- **Ports** : publiés sur `127.0.0.1` uniquement ; `inventory`, les ports internes du Collector, de Jaeger (OTLP) ne sont pas publiés.
- **Réseaux segmentés** : `app-net` (application + Collector) et `obs-net` (backends + Grafana). L'application ne peut joindre ni Prometheus, ni Grafana, ni Loki ; le Collector est le seul pont.
- **Secrets** : mot de passe Grafana obligatoire, lu depuis `.env` (exclu de Git) ; aucune valeur par défaut faible n'est codée en dur dans `compose.yaml`.
- **Grafana** : inscription et accès anonyme désactivés, Gravatar et télémétrie désactivés, cookie `SameSite=strict`, sources de données non modifiables.
- **Conteneurs applicatifs** : utilisateur non-root, système de fichiers en lecture seule, `cap_drop: ALL`, `no-new-privileges`, limites mémoire, rotation des logs Docker.
- **Données personnelles** : données fictives ; e-mails et noms masqués dans les réponses ; aucune donnée utilisateur dans les attributs de spans, métriques ou logs ; pas d'adresse IP ni de query string dans les logs d'accès ; masquage pino (`authorization`, `cookie`, `password`, `email`, `token`) ; suppression défensive dans le Collector (`attributes/scrub`).
- **Erreurs** : réponses génériques, sans pile d'appel ni détail d'infrastructure ; le détail reste dans les logs et traces internes.
- **Cardinalité** : labels limités à la route *modèle* (`/api/users`, jamais l'URL brute), routes inconnues regroupées sous `unmatched`.

## 17. Limites du projet

- **Mono-nœud** : un seul Collector, un seul Prometheus, Loki et Jaeger en mode monolithique avec stockage local ; pas de haute disponibilité.
- **Pas de TLS ni d'authentification** entre composants ni sur Prometheus/Jaeger/Loki (acceptable uniquement parce que tout est lié à `127.0.0.1`).
- **Pas de notification d'alertes** : règles évaluées par Prometheus mais pas d'Alertmanager.
- **Échantillonnage à 100 %** : adapté à la démonstration, trop coûteux à fort trafic.
- **Pas d'exemplars affichés** : le format OpenMetrics est activé côté Collector mais le lien métrique → trace n'est pas configuré dans Grafana.
- **Base de données simulée** : les spans `db.query` sont fictifs.
- **Healthchecks Docker** impossibles sur les images distroless (Collector, Jaeger, Loki) : leur santé est contrôlée par le receiver `http_check`, la métrique `up` et les tests.
- Le tableau de bord du Collector utilise les noms des métriques internes de la v0.162 ; ces noms peuvent évoluer avec les versions (les requêtes utilisent des expressions régulières tolérantes aux suffixes).

## 18. Pistes d'amélioration pour la production

1. **Sécurité** : TLS/mTLS entre SDK, Collector et backends ; authentification OTLP (extension `bearertokenauth` ou `oidc`) ; reverse proxy authentifiant (SSO) devant Grafana, Prometheus, Jaeger ; secrets via Docker secrets / Vault ; Grafana derrière HTTPS.
2. **Collector en deux niveaux** : un *agent* par hôte/pod (DaemonSet) + une *gateway* centrale en plusieurs réplicas derrière un load balancer ; `tail_sampling` (garder 100 % des traces en erreur ou lentes, 10 % du reste).
3. **Stockage scalable** : Prometheus → Mimir ou Thanos (remote-write, rétention longue) ; Jaeger → Elasticsearch/OpenSearch/Cassandra ou Grafana Tempo ; Loki en mode *simple scalable* sur stockage objet (S3, GCS, MinIO).
4. **Alerting** : Alertmanager (e-mail, Slack, PagerDuty) ou Grafana Alerting ; SLO (disponibilité 99,9 %, p95 < 300 ms) avec alertes multi-fenêtres de *burn rate*.
5. **Corrélation avancée** : exemplars Prometheus → Jaeger ; connecteur `spanmetrics` pour dériver des métriques RED de toutes les traces ; `servicegraph` pour la carte des services.
6. **Kubernetes** : Helm charts / OpenTelemetry Operator (injection automatique de l'instrumentation), `k8sattributes` processor.
7. **CI/CD** : `otelcol validate`, `promtool check config`, lint du tableau de bord, exécution du test `e2e` dans le pipeline ; scan des images (Trivy) et mise à jour automatique des versions (Renovate).
8. **Coûts et performance** : filtrage (`filter` processor) des données inutiles, compression, limitation de la cardinalité, rétentions différenciées.
9. **Profilage continu** (quatrième signal) avec Pyroscope.

## 19. État de validation

Ce qui a été **exécuté et vérifié** lors de la réalisation :

- tests de l'API (`npm test`) : 10/10 réussis ;
- exécution des deux services avec le **vrai SDK OpenTelemetry** exportant vers un récepteur OTLP de test : une requête `/api/products` produit une seule trace couvrant `demo-api` et `inventory-service` ; les erreurs ont le statut `ERROR` ; `/health` n'est pas tracé ; toutes les métriques listées au §8 sont émises avec les attributs et bornes d'histogramme attendus ; les logs portent `trace_id`/`span_id` ;
- `docker compose config` : fichier Compose valide (et refus explicite sans mot de passe Grafana) ;
- validité syntaxique de tous les fichiers YAML et du JSON du tableau de bord ;
- analyse syntaxique des 57 expressions PromQL/LogQL (tableau de bord, règles d'alerte, test E2E) avec les parseurs officiels de Prometheus et Grafana : 0 erreur.

Ce qui **reste à vérifier sur votre machine** (l'environnement de réalisation n'avait pas accès aux registres d'images Docker) : le démarrage effectif des conteneurs du Collector, de Prometheus, Jaeger, Loki et Grafana avec les versions épinglées. La commande `docker compose --profile test run --rm e2e` effectue cette vérification complète de manière automatique ; en cas d'échec, la section 15 indique comment diagnostiquer, et la commande `otelcol-contrib validate` (ligne « invalid keys » du tableau) valide la configuration du Collector isolément.
