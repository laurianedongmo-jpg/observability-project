#!/usr/bin/env bash
# =============================================================================
# Vérifications manuelles rapides depuis l'hôte (curl uniquement).
# Usage : ./tests/smoke.sh
# Pour la suite complète et automatisée : docker compose --profile test run --rm e2e
# =============================================================================
set -uo pipefail

API="${API_URL:-http://127.0.0.1:8080}"
PROM="${PROMETHEUS_URL:-http://127.0.0.1:9090}"
JAEGER="${JAEGER_URL:-http://127.0.0.1:16686}"
LOKI="${LOKI_URL:-http://127.0.0.1:3100}"
GRAFANA="${GRAFANA_URL:-http://127.0.0.1:3000}"
COLLECTOR="${COLLECTOR_HEALTH_URL:-http://127.0.0.1:13133/}"

pass=0; fail=0
expect() { # expect <description> <code_attendu> <url>
  local code
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$3")
  if [ "$code" = "$2" ]; then echo "PASS  $1 (HTTP $code)"; pass=$((pass+1));
  else echo "FAIL  $1 (HTTP $code, attendu $2)"; fail=$((fail+1)); fi
}

echo "== Disponibilité =="
expect "API /health"             200 "$API/health"
expect "Collector health_check"  200 "$COLLECTOR"
expect "Prometheus prêt"         200 "$PROM/-/ready"
expect "Jaeger UI / API"         200 "$JAEGER/api/services"
expect "Loki prêt"               200 "$LOKI/ready"
expect "Grafana santé"           200 "$GRAFANA/api/health"

echo "== Routes de l'API =="
expect "GET /"                   200 "$API/"
expect "GET /api/users"          200 "$API/api/users"
expect "GET /api/products"       200 "$API/api/products"
expect "GET /api/slow"           200 "$API/api/slow?delay=1200"
expect "GET /api/error"          500 "$API/api/error"
expect "GET /api/error?code=503" 503 "$API/api/error?code=503"
expect "Route inconnue"          404 "$API/nexiste-pas"
expect "delay invalide"          400 "$API/api/slow?delay=abc"

echo
echo "Résultat : $pass réussis, $fail échoués."
echo "Les métriques apparaissent dans Prometheus après ~10-25 s (export 10 s + scrape 15 s)."
[ "$fail" -eq 0 ]
