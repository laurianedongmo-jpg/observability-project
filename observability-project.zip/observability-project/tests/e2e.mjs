// =============================================================================
// Test de bout en bout de la plateforme d'observabilité.
//
// Exécution recommandée (aucune dépendance sur l'hôte, réseau Docker interne) :
//   docker compose --profile test run --rm e2e
// Exécution depuis l'hôte (Node.js >= 22), services publiés sur 127.0.0.1 :
//   GRAFANA_PASSWORD=... node tests/e2e.mjs
//
// Étapes :
//   1. Disponibilité de tous les composants
//   2. Génération de trafic (succès, lenteurs, erreurs, 404)
//   3. Métriques présentes dans Prometheus (via le Collector)
//   4. Traces présentes dans Jaeger (dont une trace distribuée api -> inventory)
//   5. Logs présents dans Loki, corrélés aux traces (trace_id)
//   6. Grafana : sources de données saines et tableau de bord provisionné
// =============================================================================

const env = (name, def) => process.env[name] || def;
const API = env('API_URL', 'http://127.0.0.1:8080');
const COLLECTOR_HEALTH = env('COLLECTOR_HEALTH_URL', 'http://127.0.0.1:13133/');
const PROM = env('PROMETHEUS_URL', 'http://127.0.0.1:9090');
const JAEGER = env('JAEGER_URL', 'http://127.0.0.1:16686');
const JAEGER_HEALTH = env('JAEGER_HEALTH_URL', '');
const LOKI = env('LOKI_URL', 'http://127.0.0.1:3100');
const GRAFANA = env('GRAFANA_URL', 'http://127.0.0.1:3000');
const GRAFANA_AUTH = 'Basic ' + Buffer.from(`${env('GRAFANA_USER', 'admin')}:${env('GRAFANA_PASSWORD', '')}`).toString('base64');
const TIMEOUT_MS = Number(env('E2E_TIMEOUT_MS', '120000'));

const results = [];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const color = (c, s) => (process.stdout.isTTY ? `\x1b[${c}m${s}\x1b[0m` : s);

async function http(url, opts = {}) {
  const res = await fetch(url, { signal: AbortSignal.timeout(10_000), ...opts });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = undefined; }
  return { status: res.status, ok: res.ok, text, json };
}

/** Réessaie `fn` jusqu'à ce qu'il renvoie une valeur « vraie » ou expiration. */
async function eventually(fn, timeoutMs = TIMEOUT_MS, intervalMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  let lastErr;
  while (Date.now() < deadline) {
    try {
      const v = await fn();
      if (v) return v;
    } catch (err) { lastErr = err; }
    await sleep(intervalMs);
  }
  throw new Error(`délai dépassé (${timeoutMs / 1000}s)${lastErr ? ` - dernière erreur : ${lastErr.message}` : ''}`);
}

async function check(name, fn) {
  const t0 = Date.now();
  try {
    const detail = await fn();
    results.push({ name, ok: true });
    console.log(`${color(32, 'PASS')} ${name}${detail ? ` -> ${detail}` : ''} (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  } catch (err) {
    results.push({ name, ok: false });
    console.log(`${color(31, 'FAIL')} ${name} -> ${err.message}`);
  }
}

async function promQuery(expr) {
  const r = await http(`${PROM}/api/v1/query?query=${encodeURIComponent(expr)}`);
  if (r.json?.status !== 'success') throw new Error(`requête PromQL en échec: ${r.text.slice(0, 200)}`);
  return r.json.data.result;
}

async function promScalar(expr) {
  const res = await promQuery(expr);
  return res.length ? Number(res[0].value[1]) : 0;
}

// -----------------------------------------------------------------------------
console.log('\n== 1. Disponibilité des composants ==');
await check('API /health', () => eventually(async () => {
  const r = await http(`${API}/health`);
  return r.status === 200 && r.json?.status === 'ok' && 'HTTP 200 {status: ok}';
}));
await check('OpenTelemetry Collector (health_check :13133)', () => eventually(async () => (await http(COLLECTOR_HEALTH)).status === 200 && 'HTTP 200'));
await check('Prometheus /-/ready', () => eventually(async () => (await http(`${PROM}/-/ready`)).status === 200 && 'HTTP 200'));
if (JAEGER_HEALTH) {
  await check('Jaeger (healthcheckv2 /status)', () => eventually(async () => (await http(JAEGER_HEALTH)).status === 200 && 'HTTP 200'));
}
await check('Jaeger API /api/services', () => eventually(async () => (await http(`${JAEGER}/api/services`)).status === 200 && 'HTTP 200'));
await check('Loki /ready', () => eventually(async () => (await http(`${LOKI}/ready`)).status === 200 && 'HTTP 200'));
await check('Grafana /api/health', () => eventually(async () => (await http(`${GRAFANA}/api/health`)).json?.database === 'ok' && 'database ok'));

// -----------------------------------------------------------------------------
console.log('\n== 2. Génération de trafic ==');
const plan = [
  ...Array(15).fill('/'),
  ...Array(20).fill('/api/users'),
  ...Array(20).fill('/api/products'),
  ...Array(5).fill('/api/slow?delay=1500'),
  ...Array(6).fill('/api/error'),
  ...Array(4).fill('/api/error?code=503'),
  ...Array(5).fill('/route-inexistante'),
];
const counts = {};
let errorTraceId;
await check(`Envoi de ${plan.length} requêtes`, async () => {
  await Promise.all(plan.map(async (path, i) => {
    await sleep(i * 20);
    const r = await http(`${API}${path}`);
    const key = `${path.split('?')[0]} ${r.status}`;
    counts[key] = (counts[key] || 0) + 1;
    if (path === '/api/error' && r.json?.traceId) errorTraceId = r.json.traceId;
  }));
  return JSON.stringify(counts);
});
await check('Réponses conformes (200 / 500 / 503 / 404)', async () => {
  const expected = { '/api/users 200': 20, '/api/products 200': 20, '/api/slow 200': 5, '/api/error 500': 6, '/api/error 503': 4, '/route-inexistante 404': 5 };
  for (const [k, v] of Object.entries(expected)) {
    if (counts[k] !== v) throw new Error(`${k}: attendu ${v}, obtenu ${counts[k] || 0}`);
  }
  return 'OK';
});
await check('Erreur 500 sans fuite d\'information interne', async () => {
  const r = await http(`${API}/api/error`);
  if (/db-primary|5432|stack|\.js:/i.test(r.text)) throw new Error(`réponse trop bavarde: ${r.text}`);
  if (!/^[0-9a-f]{32}$/.test(r.json?.traceId || '')) throw new Error('traceId absent de la réponse');
  errorTraceId = r.json.traceId;
  return `message="${r.json.error.message}" traceId=${errorTraceId}`;
});

// -----------------------------------------------------------------------------
console.log('\n== 3. Métriques dans Prometheus (App -> OTLP -> Collector :8889 <- scrape Prometheus) ==');
const JOB = 'job=~".*demo-api"';
await check('Cibles Prometheus "up"', () => eventually(async () => {
  const res = await promQuery('up');
  const down = res.filter((s) => s.value[1] !== '1').map((s) => s.metric.job);
  const jobs = res.map((s) => s.metric.job);
  for (const j of ['otel-collector', 'otel-collector-app-metrics', 'jaeger', 'loki', 'grafana', 'prometheus']) {
    if (!jobs.includes(j)) return false;
  }
  return down.length === 0 && `${res.length} cibles UP`;
}));
await check('Compteur app_http_requests_total (routes /api/users)', () => eventually(async () => {
  const v = await promScalar(`sum(app_http_requests_total{${JOB}, http_route="/api/users"})`);
  return v >= 20 && `${v} requêtes`;
}));
await check('Erreurs 5xx comptabilisées', () => eventually(async () => {
  const v = await promScalar(`sum(app_http_requests_total{${JOB}, http_route="/api/error", http_response_status_class="5xx"})`);
  return v >= 10 && `${v} réponses 5xx`;
}));
await check('Requêtes lentes comptabilisées (app_http_slow_requests_total)', () => eventually(async () => {
  const v = await promScalar(`sum(app_http_slow_requests_total{${JOB}, http_route="/api/slow"})`);
  return v >= 5 && `${v} requêtes lentes`;
}));
await check('Histogramme de durée + percentile p95 calculable', () => eventually(async () => {
  const v = await promScalar(`histogram_quantile(0.95, sum by (le) (app_http_request_duration_seconds_bucket{${JOB}, http_route="/api/slow"}))`);
  return v >= 1 && `p95(/api/slow) = ${v.toFixed(2)} s`;
}));
await check('Métrique standard http_server_request_duration_seconds (instrumentation auto)', () => eventually(async () => {
  const v = await promScalar(`sum(http_server_request_duration_seconds_count{${JOB}})`);
  return v > 0 && `${v} mesures`;
}));
await check('Service inventory instrumenté', () => eventually(async () => {
  const v = await promScalar('sum(app_http_requests_total{job=~".*inventory-service", http_route="/inventory/stock"})');
  return v >= 20 && `${v} requêtes`;
}));
await check('Sondes http_check du Collector (httpcheck_status)', () => eventually(async () => {
  const res = await promQuery('max by (http_url) (httpcheck_status{http_status_class="2xx"})');
  const ok = res.filter((s) => s.value[1] === '1').length;
  return res.length >= 6 && ok === res.length && `${ok}/${res.length} endpoints sains`;
}));
await check('Métriques internes du Collector', () => eventually(async () => {
  const v = await promScalar('sum({__name__=~"otelcol_receiver_accepted_spans(_total)?"})');
  return v > 0 && `${v} spans acceptés`;
}));

// -----------------------------------------------------------------------------
console.log('\n== 4. Traces dans Jaeger (App -> OTLP -> Collector -> OTLP/gRPC -> Jaeger) ==');
await check('Services connus de Jaeger', () => eventually(async () => {
  const services = (await http(`${JAEGER}/api/services`)).json?.data || [];
  return services.includes('demo-api') && services.includes('inventory-service') && services.join(', ');
}));
await check('Trace distribuée GET /api/products (demo-api -> inventory-service)', () => eventually(async () => {
  const q = new URLSearchParams({ service: 'demo-api', operation: 'GET /api/products', limit: '5', lookback: '1h' });
  const traces = (await http(`${JAEGER}/api/traces?${q}`)).json?.data || [];
  const t = traces.find((tr) => Object.values(tr.processes).some((p) => p.serviceName === 'inventory-service'));
  return t && `trace ${t.traceID} : ${t.spans.length} spans, services = ${[...new Set(Object.values(t.processes).map((p) => p.serviceName))].join(' + ')}`;
}));
await check('Trace d\'erreur retrouvée par son traceId', () => eventually(async () => {
  const r = await http(`${JAEGER}/api/traces/${errorTraceId}`);
  const spans = r.json?.data?.[0]?.spans || [];
  const errored = spans.filter((s) => s.tags.some((t) => t.key === 'error' && (t.value === true || t.value === 'true')));
  return errored.length > 0 && `${spans.length} spans dont ${errored.length} en erreur`;
}));
await check('Span lent visible (simulate.slow_operation >= 1,5 s)', () => eventually(async () => {
  const q = new URLSearchParams({ service: 'demo-api', operation: 'GET /api/slow', limit: '5', lookback: '1h', minDuration: '1.4s' });
  const traces = (await http(`${JAEGER}/api/traces?${q}`)).json?.data || [];
  const span = traces.flatMap((t) => t.spans).find((s) => s.operationName === 'simulate.slow_operation');
  return span && `durée ${(span.duration / 1e6).toFixed(2)} s`;
}));

// -----------------------------------------------------------------------------
console.log('\n== 5. Logs dans Loki (App -> OTLP -> Collector -> OTLP/HTTP -> Loki) ==');
async function lokiQuery(query, sinceMinutes = 30) {
  const end = BigInt(Date.now()) * 1_000_000n;
  const start = end - BigInt(sinceMinutes * 60) * 1_000_000_000n;
  const q = new URLSearchParams({ query, start: start.toString(), end: end.toString(), limit: '100', direction: 'backward' });
  const r = await http(`${LOKI}/loki/api/v1/query_range?${q}`);
  if (r.json?.status !== 'success') throw new Error(`requête LogQL en échec: ${r.text.slice(0, 200)}`);
  return r.json.data.result.flatMap((s) => s.values);
}
await check('Logs de demo-api présents', () => eventually(async () => {
  const lines = await lokiQuery('{service_name="demo-api"}');
  return lines.length > 0 && `${lines.length} lignes (extrait : ${lines[0][1].slice(0, 60)})`;
}));
await check('Logs d\'erreur filtrables (severity_text="error")', () => eventually(async () => {
  const lines = await lokiQuery('{service_name="demo-api"} | severity_text="error"');
  return lines.length > 0 && `${lines.length} lignes`;
}));
await check('Corrélation log <-> trace (trace_id de l\'erreur)', () => eventually(async () => {
  const lines = await lokiQuery(`{service_name="demo-api"} | trace_id="${errorTraceId}"`);
  return lines.length > 0 && `${lines.length} log(s) pour la trace ${errorTraceId}`;
}));
await check('Logs du service inventory présents', () => eventually(async () => {
  const lines = await lokiQuery('{service_name="inventory-service"}');
  return lines.length > 0 && `${lines.length} lignes`;
}));

// -----------------------------------------------------------------------------
console.log('\n== 6. Grafana ==');
const gf = (path) => http(`${GRAFANA}${path}`, { headers: { authorization: GRAFANA_AUTH } });
await check('Authentification admin Grafana', async () => {
  const r = await gf('/api/user');
  if (r.status !== 200) throw new Error(`HTTP ${r.status} (vérifiez GRAFANA_PASSWORD)`);
  return `connecté en tant que ${r.json.login}`;
});
await check('Accès anonyme refusé', async () => {
  const r = await http(`${GRAFANA}/api/dashboards/uid/obs-demo-overview`);
  if (r.status !== 401) throw new Error(`HTTP ${r.status}, attendu 401`);
  return 'HTTP 401';
});
for (const uid of ['prometheus', 'loki', 'jaeger']) {
  await check(`Source de données "${uid}" opérationnelle`, () => eventually(async () => {
    const r = await gf(`/api/datasources/uid/${uid}/health`);
    if (r.status !== 200) throw new Error(`HTTP ${r.status}: ${r.text.slice(0, 150)}`);
    return `${r.json.status} - ${r.json.message}`;
  }, 60_000));
}
await check('Tableau de bord provisionné', async () => {
  const r = await gf('/api/dashboards/uid/obs-demo-overview');
  if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
  return `"${r.json.dashboard.title}" (${r.json.dashboard.panels.length} panneaux)`;
});
await check('Requête PromQL exécutée via Grafana', async () => {
  const body = {
    from: 'now-15m', to: 'now',
    queries: [{ refId: 'A', datasource: { uid: 'prometheus', type: 'prometheus' }, expr: 'sum(app_http_requests_total)', instant: true }],
  };
  const r = await http(`${GRAFANA}/api/ds/query`, {
    method: 'POST', headers: { authorization: GRAFANA_AUTH, 'content-type': 'application/json' }, body: JSON.stringify(body),
  });
  const frame = r.json?.results?.A?.frames?.[0];
  const value = frame?.data?.values?.[1]?.[0];
  if (r.status !== 200 || value === undefined) throw new Error(`HTTP ${r.status}: ${r.text.slice(0, 200)}`);
  return `sum(app_http_requests_total) = ${value}`;
});

// -----------------------------------------------------------------------------
const failed = results.filter((r) => !r.ok);
console.log(`\n== Résultat : ${results.length - failed.length}/${results.length} vérifications réussies ==`);
if (failed.length) {
  console.log(color(31, `Échecs : ${failed.map((f) => f.name).join(' | ')}`));
  console.log('Diagnostic : docker compose ps ; docker compose logs otel-collector ; voir README section « Diagnostic ».');
  process.exit(1);
}
console.log(color(32, 'Plateforme d\'observabilité opérationnelle.'));
