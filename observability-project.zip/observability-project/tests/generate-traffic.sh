#!/usr/bin/env bash
# =============================================================================
# Générateur de trafic continu pour alimenter le tableau de bord Grafana.
# Usage : ./tests/generate-traffic.sh [durée_en_secondes] [url_api]
#   ./tests/generate-traffic.sh 300
# Répartition approximative : 70 % succès, 10 % lent, 10 % erreur, 10 % 404.
# Arrêt : Ctrl+C
# =============================================================================
set -euo pipefail

DURATION="${1:-120}"
API="${2:-http://127.0.0.1:8080}"
END=$(( $(date +%s) + DURATION ))
COUNT=0

command -v curl >/dev/null || { echo "curl est requis" >&2; exit 1; }
curl -fsS "$API/health" >/dev/null || { echo "API injoignable sur $API" >&2; exit 1; }

echo "Génération de trafic vers $API pendant ${DURATION}s..."
while [ "$(date +%s)" -lt "$END" ]; do
  r=$(( RANDOM % 100 ))
  if   [ $r -lt 25 ]; then path="/api/users"
  elif [ $r -lt 50 ]; then path="/api/products"
  elif [ $r -lt 70 ]; then path="/"
  elif [ $r -lt 80 ]; then path="/api/slow"
  elif [ $r -lt 87 ]; then path="/api/error"
  elif [ $r -lt 90 ]; then path="/api/error?code=503"
  else                     path="/page-inconnue"
  fi
  # Requêtes en arrière-plan pour simuler plusieurs clients simultanés.
  curl -s -o /dev/null -w "%{http_code} $path\n" "$API$path" &
  COUNT=$((COUNT + 1))
  sleep 0.2
done
wait
echo "Terminé : $COUNT requêtes envoyées."
